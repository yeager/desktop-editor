"""Desktop File Editor — visual editor for .desktop files."""
__version__ = "0.1.0"
